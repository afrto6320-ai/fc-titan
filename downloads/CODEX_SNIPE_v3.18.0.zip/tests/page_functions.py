"""Chromium MAIN/ISOLATED boundary + selected methods from supplied EA source.

Scripts are installed into actual browser worlds using CDP. Chrome runtime/storage
are stubbed only in the isolated world; this does not validate extension installation.

Vendor source stays outside the extension. Pass FC_EA_SOURCE_DIR pointing to the
captured js directory; the test fails if that source is unavailable.
"""
from pathlib import Path
import json, os, base64
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent.parent
SOURCE=Path(os.environ.get('FC_EA_SOURCE_DIR', '/workspace/fc-captured-webapp/FC_WebApp_Archive_v3/assets/www.ea.com/ea-sports-fc/ultimate-team/web-app/js'))
source=(SOURCE/'compiled_3.js').read_text()
methods=['eSearchSelected','eFilterChanged','ePlayerNameChanged','eMinBidPriceChanged',
         'eMaxBidPriceChanged','eMinBuyPriceChanged','eMaxBuyPriceChanged']

def extract_method(name,text=source,owner='UTMarketSearchFiltersViewController'):
    prefix=owner+'.prototype.'+name+'=function'
    start=text.index(prefix)
    body=text.index('{',start)
    depth=0;quote=None;escaped=False
    for i in range(body,len(text)):
        char=text[i]
        if quote:
            if escaped: escaped=False
            elif char=='\\': escaped=True
            elif char==quote: quote=None
        elif char in "'\"`": quote=char
        elif char=='{': depth+=1
        elif char=='}':
            depth-=1
            if depth==0:return text[start:i+1]+';'
    raise AssertionError('Unterminated source method '+name)

contracts='\n'.join(extract_method(name) for name in methods)
contracts+='\n'+extract_method('bid',(SOURCE/'compiled_2.js').read_text(),'UTItemActionController')
contracts+='\n'+extract_method('move',(SOURCE/'compiled_2.js').read_text(),'UTItemActionController')
contracts+='\n'+extract_method('eMaxBuyPriceChanged',source,'UTMarketSearchFiltersView')
prefix=(ROOT/'tests/fixture33.html').read_text().split('<script>')[0]
html=prefix+'<script>'+(ROOT/'tests/ea_harness.js').read_text()+'\n'+contracts+'</script></body></html>'
URL='https://www.ea.com/ea-sports-fc/ultimate-team/web-app/'

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1500,'height':1000},accept_downloads=True)
    context.route('https://www.ea.com/**',lambda route:route.fulfill(status=200,content_type='text/html',body=html) if route.request.url==URL else route.abort())
    page=context.new_page();errors=[]
    page.route('**/test-portraits/**',lambda route:route.fulfill(status=200,content_type='image/svg+xml',body='<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20" fill="blue"/></svg>'))
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(URL)
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for entry in manifest['content_scripts']:
      if entry.get('world')=='MAIN':
        for filename in entry['js']:page.add_script_tag(content=(ROOT/filename).read_text())
    cdp=context.new_cdp_session(page)
    frame=cdp.send('Page.getFrameTree')['frameTree']['frame']['id']
    world=cdp.send('Page.createIsolatedWorld',{'frameId':frame,'worldName':'gpts-test-extension'})['executionContextId']
    css='data:text/css;base64,'+base64.b64encode((ROOT/'embedded.css').read_bytes()).decode()
    stale={'name':'Mohamed Salah','rating':88,'itemId':50540979,'playerId':None,'source':'futgg','key':'item:50540979'}
    stored={'gpts_embedded_v3':{'selected':stale,'selectedTargets':[stale],'settings':{'player':'Mohamed Salah','itemId':'50540979','searchRoute':'screen','bidLadder':'off'}}}
    shim='window.chrome={runtime:{getURL:()=>'+json.dumps(css)+',sendMessage:async()=>{throw Error("Unexpected external catalogue request")}},storage:{local:{get:async()=>('+json.dumps(stored)+'),set:async()=>{}}}};'
    shim+='window.__playedTones=0;const originalOscillator=AudioContext.prototype.createOscillator;AudioContext.prototype.createOscillator=function(){window.__playedTones++;return originalOscillator.call(this);};'
    scripts=[name for entry in manifest['content_scripts'] if entry.get('world','ISOLATED')=='ISOLATED' for name in entry['js']]
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':shim})
    for filename in scripts:
      loaded=cdp.send('Runtime.evaluate',{'contextId':world,'expression':(ROOT/filename).read_text()+'\n//# sourceURL=chrome-extension://codex-fixture/'+filename})
      assert 'exceptionDetails' not in loaded,loaded
    helpers=cdp.send('Runtime.evaluate',{'contextId':world,'expression':'[typeof CodexEngineModes.get,typeof CodexTradeCore.pace,typeof CodexEAOptions.groups]','returnByValue':True})
    assert helpers['result']['value']==['function']*3
    print('PASS: isolated scripts loaded individually in manifest order expose all required UI helpers')
    def request(command,args=None):
        expression='GPTPageClient.request('+json.dumps(command)+','+json.dumps(args or {})+').then(result=>({ok:true,result}),e=>({ok:false,code:e.code,message:e.message}))'
        result=cdp.send('Runtime.evaluate',{'contextId':world,'expression':expression,'awaitPromise':True,'returnByValue':True})
        assert 'exceptionDetails' not in result,result
        return result['result']['value']
    try:
        page.locator('#gpts-v3-nav').click(timeout=8000)
    except Exception:
        print('Extension diagnostics:',[w.url for w in context.service_workers],errors,
              page.evaluate('({bridge:typeof window.__GPT_EA_PAGE_BRIDGE_V1__, app:typeof getAppMain, title:document.title})'),flush=True)
        raise
    sh=page.locator('#gpts-v3-host')
    # Real Chrome isolated world: page cannot reach the isolated client.
    assert page.evaluate('typeof window.GPTPageClient')=='undefined'
    assert page.evaluate('window.__GPT_EA_PAGE_BRIDGE_V1__') is True
    sh.locator('#player').fill('moha')
    sh.locator('#playerResults .result .avatar img').first.wait_for()
    assert 'EA native' in sh.locator('#provider').inner_text()
    sh.locator('#maxBin').fill('1000');sh.locator('#maxSearches').fill('1')
    sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#nativeConnectStatus').textContent.includes('PAGE FUNCTIONS')")
    assert page.locator('.ut-market-search-filters-view button').count()==0
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#playerSyncState').textContent.includes('ea-database-mask')")
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#searchCount').textContent==='1'")
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#runBadge').textContent.includes('STANDBY')")
    assert request('connect')['ok']
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.maskedDefId')==209331
    assert sh.locator('#itemId').input_value()=='50540979'
    page.evaluate('window.__testSearches=0;window.__testCacheClears=0')
    sh.locator('#clearTargets').click()
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.maskedDefId===0')
    print('PASS: catalogue 50540979 to EA 209331, prefix-only engine, one-click native connection and confirmation')
    print('PASS: actual Chromium isolated world; native navigation without a DOM Search button')

    assert sh.locator('[data-native-picker="club"]').is_disabled()
    assert request('options',{'kind':'club'})['code']=='LEAGUE_REQUIRED'
    page.evaluate('window.__leagueDelay=250;window.__leagueChoices=0')
    sh.locator('[data-native-picker="league"]').click()
    sh.locator('.native-option').filter(has_text='LaLiga').click()
    assert sh.locator('#start').is_disabled()
    page.wait_for_function("!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('[data-native-picker=club]').disabled")
    assert page.evaluate('__leagueChoices')==1
    page.evaluate('window.__leagueDelay=0')
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.league===53')
    sh.locator('[data-native-picker="club"]').click()
    sh.locator('.native-option').filter(has_text='Real Madrid').wait_for()
    assert sh.locator('.native-option').filter(has_text='Liverpool').count()==0
    sh.locator('.native-option').filter(has_text='Real Madrid').click()
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.club===243')
    sh.locator('[data-native-picker="league"]').click();sh.locator('.native-option').filter(has_text='Any league').click()
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.league===-1')
    sh.locator('#nativePickerArea').wait_for(state='hidden')
    assert sh.locator('[data-native-picker="club"]').is_disabled()
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.club')==-1
    assert request('options',{'kind':'club'})['code']=='LEAGUE_REQUIRED'
    sh.locator('[data-native-picker="league"]').click();sh.locator('.native-option').filter(has_text='LaLiga').click()
    sh.locator('[data-native-picker="club"]').click();sh.locator('.native-option').filter(has_text='Real Madrid').click()
    print('PASS: native option collections, selection handlers, dependent club choices')

    sh.locator('#player').fill('Salah')
    sh.locator('#playerResults .result .avatar img').first.wait_for()
    assert sh.locator('#playerResults .result .avatar img').first.get_attribute('src').endswith('/209331.svg')
    sh.locator('#playerResults .result').first.click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#playerSyncState').textContent.includes('209331')")
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.maskedDefId')==209331
    assert sh.locator('#selectedTargets .target-chip').count()==1
    assert sh.locator('#itemId').input_value()==''
    scoped=request('options',{'kind':'event'})['result']
    assert scoped['meta']['scope']=='selected-player'
    assert [x['id'] for x in scoped['options']]==[-1,1,12]
    page.evaluate('window.__conceptFn=services.Item.searchConceptItems;services.Item.searchConceptItems=undefined')
    assert request('options',{'kind':'event','refresh':True})['code']=='EDITIONS_UNAVAILABLE'
    page.evaluate('()=>{services.Item.searchConceptItems=window.__conceptFn;}')
    sh.locator('[data-native-picker="event"]').click()
    sh.locator('.native-option').filter(has_text='Icon').wait_for()
    assert sh.locator('.native-option').filter(has_text='Unrelated event').count()==0
    sh.locator('.native-option').filter(has_text='Icon').click()
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.rarities[0]===12')
    print('PASS: native local player lookup, exact base-player ID, separate rarity selection')

    sh.locator('#maxBin').fill('1000');sh.locator('#maxSearches').fill('2')
    sh.locator('#sync').click()
    page.wait_for_function('window.__nativeMaxBin===1000')
    sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#searchCount').textContent==='1'")
    offset=sh.locator('#cycleRing').evaluate('(e)=>e.style.strokeDashoffset')
    page.wait_for_function('(old)=>document.querySelector("#gpts-v3-host").shadowRoot.querySelector("#cycleRing").style.strokeDashoffset!==old',arg=offset)
    page.wait_for_function('window.__testSearches===2',timeout=12000)
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#runBadge').textContent.includes('STANDBY')")
    assert page.evaluate('window.__testCacheClears')==4
    assert page.evaluate('__testObservers.size')==0
    assert sh.locator('#searchCount').inner_text()=='2'
    print('PASS: source-derived native search and price handlers, fresh empty responses, repeat search')

    # Export reports contain only the whitelisted snapshot, never the full user object.
    with page.expect_download() as dl: sh.locator('#exportConnection').click()
    report=Path(dl.value.path()).read_text()
    assert json.loads(report)['mode']=='page-functions'
    assert 'PRIVATE-SENTINEL' not in report
    print('PASS: native connection report export and data minimization')

    # Stop while an EA request is in flight: detach listener, count no unconfirmed result.
    page.evaluate('window.__testDelay=1800;window.__testSearches=0')
    sh.locator('#start').click()
    page.wait_for_function('window.__testSearches===1')
    sh.locator('#stop').click()
    page.wait_for_timeout(2300)
    assert page.evaluate('window.__testSearches')==1
    assert page.evaluate('__testObservers.size')==0
    assert sh.locator('#searchCount').inner_text()=='0'
    print('PASS: Stop detaches native pending result and prevents another search')

    # A real result event is serialized, checked and produces an alert without a purchase.
    page.evaluate("window.__testDelay=50;window.__testSearches=0;resetTrade('alert-trade')")
    sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#matchCount').textContent==='1'")
    assert sh.locator('#buyCount').inner_text()=='0'
    assert '50540979' in sh.locator('#nativeOffers').inner_text()
    assert page.evaluate('__testSearches')==1
    print('PASS: authoritative native result ID/rarity/price, matching alert, zero purchases')

    # Native buy uses the original object/action contract, without a DOM row or general popup.
    dialogs=[];approve=[False]
    def dialog_handler(dialog):
        dialogs.append(dialog.message)
        dialog.accept() if approve[0] else dialog.dismiss()
    page.on('dialog',dialog_handler)
    page.evaluate("resetTrade('native-buy-1');window.__bidScenario='won'")
    sh.locator('#autoBuy').check();sh.locator('#maxBuys').fill('1')
    sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#buyCount').textContent==='1'")
    assert page.evaluate('__bidCalls')==1 and page.evaluate('__lastBidItem===__testItems[0]')
    assert sh.locator('#spent').inner_text()=='900' and not dialogs
    audio_check=cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__playedTones','returnByValue':True})
    assert audio_check['result']['value']>=4
    assert 'already pending' not in sh.locator('#playerResults').inner_text()
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=0')
    page.screenshot(path='/tmp/CODEX_SNIPE_v3.5.0_gauge.png')
    print('PASS: native action-controller bid with exact EA object, confirmed isWon receipt, no general warning')

    page.evaluate("resetTrade('loss-declined')")
    page.evaluate('window.__testAverage=700');sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#sessionStatus').textContent.includes('الخسارة')")
    assert len(dialogs)==1 and page.evaluate('__bidCalls')==1
    assert sh.locator('#buyCount').inner_text()=='0'
    approve[0]=True;page.evaluate("resetTrade('loss-approved')")
    sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#buyCount').textContent==='1'")
    assert len(dialogs)==2 and page.evaluate('__bidCalls')==2
    print('PASS: >10% after-tax loss confirmation only, declined purchase sends no bid, accepted risk matches the same trade')

    # An already-dispatched purchase completes after Stop and must still be accounted once.
    page.evaluate('window.__testAverage=null');page.evaluate("resetTrade('stopped-purchase');window.__bidDelay=1300")
    sh.locator('#start').click();page.wait_for_function('__bidCalls===3')
    sh.locator('#stop').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#buyCount').textContent==='1'")
    frozen=sh.locator('#time').inner_text();page.wait_for_timeout(700)
    assert sh.locator('#time').inner_text()==frozen and sh.locator('#spent').inner_text()=='900'
    assert page.evaluate('__bidCalls')==3
    print('PASS: Stop freezes runtime, prevents new buys and records the in-flight confirmed receipt once')
    sh.locator('#autoBuy').uncheck();page.evaluate('window.__bidDelay=30')

    # Server-side identity/price/cap checks must reject before a native bid.
    snap=request('connect')['result']['snapshot']
    assert request('beginSession',{'criteriaKey':snap['criteriaKey'],'maxPrice':1000,'maxSpend':500,'maxBuys':1})['code']=='BAD_ARGUMENT'
    page.evaluate("resetTrade('limit-check')")
    limited=request('beginSession',{'criteriaKey':snap['criteriaKey'],'maxPrice':850,'maxSpend':1000,'maxBuys':1,'autoBuy':True})['result']['sessionId']
    result=request('search',{'maxBin':1000,'criteriaKey':snap['criteriaKey']})['result']
    args={'sessionId':limited,'searchId':result['searchId'],'tradeId':'limit-check','instanceId':'123456','expectedPrice':900}
    assert request('buy',args)['code']=='LIMIT'
    assert request('buy',{**args,'expectedPrice':901})['code']=='PRICE_MISMATCH'
    assert request('buy',{**args,'tradeId':'foreign-trade'})['code']=='LISTING_MISMATCH'
    assert request('buy',{**args,'instanceId':'wrong-instance'})['code']=='PRICE_MISMATCH'
    assert page.evaluate('__bidCalls')==3
    print('PASS: native budget, price and listing guards reject without dispatching a bid')

    page.evaluate("resetTrade('lost-race');window.__bidScenario='expired'")
    sh.locator('#autoBuy').check();sh.locator('#maxSearches').fill('1');sh.locator('#start').click()
    try:
        page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#misses').textContent==='1'",timeout=8000)
    except Exception:
        print('Lost-auction diagnostics:',sh.locator('#logs').inner_text(),page.evaluate('({calls:__bidCalls,scenario:__bidScenario})'),flush=True)
        raise
    assert sh.locator('#buyCount').inner_text()=='0' and sh.locator('#spent').inner_text()=='0'
    sh.locator('#autoBuy').uncheck();page.evaluate("window.__bidScenario='won'")
    assert sh.locator('.outcome-toast.missed').count()==1
    assert sh.locator('.outcome-toast.missed').evaluate('(e)=>getComputedStyle(e).animationName')=='toast-fade'
    print('PASS: lost auction counts as a miss, shows a distinct missed toast, and never counts as a purchase')

    snap=request('connect')['result']['snapshot']
    retry_session=request('beginSession',{'criteriaKey':snap['criteriaKey'],'maxPrice':1000,'maxSpend':10000,'maxBuys':1,'autoBuy':True})['result']['sessionId']
    result=request('search',{'maxBin':1000,'criteriaKey':snap['criteriaKey']})['result']
    before=page.evaluate('__bidCalls')
    repeated=request('buy',{'sessionId':retry_session,'searchId':result['searchId'],'tradeId':'lost-race','instanceId':'123456','expectedPrice':900})
    assert repeated['result']['status']=='already-attempted' and page.evaluate('__bidCalls')==before
    request('cancel')
    print('PASS: the same previously attempted Trade ID is skipped across sessions without dispatching or counting a second bid')

    assert request('connect')['ok']
    assert not request('constructor')['ok']
    assert request('applyPrices',{'maxBin':-10})['code']=='BAD_ARGUMENT'
    snap=request('readFilters')['result']
    assert request('search',{'maxBin':1001,'criteriaKey':snap['criteriaKey']})['code']=='PRICE_MISMATCH'
    assert request('search',{'maxBin':1000,'criteriaKey':'stale'})['code']=='FILTER_MISMATCH'
    assert request('selectPlayer',{'id':999999,'query':'Salah'})['code']=='PLAYER_MISMATCH'
    # Player locks the native league filter; no forced override is performed.
    opts=request('options',{'kind':'league'})['result']
    assert request('choose',{'token':opts['token'],'index':1})['code']=='FILTER_LOCKED'
    assert request('clearPlayer')['ok']
    opts=request('options',{'kind':'league'})['result']
    assert request('choose',{'token':opts['token'],'index':2})['ok']
    opts=request('options',{'kind':'club'})['result']
    page.evaluate('__nav.currentController.viewmodel.searchCriteria.league=13')
    assert request('choose',{'token':opts['token'],'index':1})['code']=='STALE_OPTIONS'
    print('PASS: fixed command allowlist, price/player/fingerprint validation, native locks, stale options')

    # Reproduce reported club duplicates, unresolved translation keys and failed badges.
    def badge(route):
        if 'fallback' in route.request.url:
            route.fulfill(status=200,content_type='image/svg+xml',body='<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="24" height="24" fill="green"/></svg>')
        else: route.fulfill(status=404,body='')
    page.route('**/test-badges/**',badge)
    page.evaluate('''(() => {
      const view=__nav.currentController.getView(),fields=view.getFilters(),ctrl=fields.searchFilters.get(enums.UISearchFilters.CLUB);
      window.__badgeOptions=[{id:-1,value:'-1',label:'Any'},
        {id:9,value:'9',label:'Same Club'},{id:9,value:'9',label:'Same Club'},
        {id:10,value:'10',label:'Same Club'},{id:99,value:'99',label:'*global.teamabbr15.2027.team99'}];
      ctrl.getOptions=()=>window.__badgeOptions.slice();ctrl.index=0;
      ctrl.iconTable=new Map([['9','/test-badges/missing.png'],['10','/test-badges/also-missing.png']]);
      view.getFilters=()=>({...fields,generateFilterImage:(kind,id)=>id===9?'/test-badges/fallback.svg':''});
    })()''')
    sh.locator('[data-native-picker="league"]').click();sh.locator('.native-option').filter(has_text='Premier League').click()
    sh.locator('[data-native-picker="club"]').click()
    sh.locator('.native-option-group summary').wait_for()
    assert sh.locator('#nativePickerResults').inner_text().count('Same Club')==1
    sh.locator('.native-option-group summary').click()
    sh.locator('.native-option[data-ea-id="9"]').wait_for()
    assert sh.locator('.native-option[data-ea-id="9"]').count()==1
    assert sh.locator('.native-option[data-ea-id="10"]').count()==1
    assert sh.locator('.native-option[data-ea-id="99"]').count()==0
    assert '1 duplicates removed' in sh.locator('#pickerStatus').inner_text() or '1 مكرر' in sh.locator('#pickerStatus').inner_text()
    sh.locator('.native-option[data-ea-id="9"][data-image-state="loaded"]').wait_for()
    sh.locator('.native-option[data-ea-id="10"][data-image-state="unavailable"]').wait_for()
    assert sh.locator('.native-option[data-ea-id="10"] img').count()==0
    sh.locator('#showUnresolvedOptions').check()
    sh.locator('.native-option[data-ea-id="99"]').wait_for()
    assert 'global.teamabbr' not in sh.locator('#nativePickerResults').inner_text()
    page.screenshot(path='/tmp/CODEX_SNIPE_3.4.2_club_groups.png')
    sh.locator('.native-option-filter').fill('10')
    assert sh.locator('.native-option').count()==1
    sh.locator('.native-option').click()
    page.wait_for_function('__nav.currentController.viewmodel.searchCriteria.club===10')
    sh.locator('#compatPanel summary').click()
    sh.locator('#runDiag').click()
    result_check=sh.locator('.audit-row').filter(has_text='Result list container')
    assert 'fail' not in (result_check.get_attribute('class') or '')
    assert sh.locator('h1').inner_text()=='CODEX SNIPE'
    print('PASS: duplicate IDs removed, distinct clubs retained, missing names disclosed, native badge fallback, correct ID selected, branding')

    # A fresh scan gathers native pages, omits overfetch sentinels, and does not buy.
    sh.locator('#resultsCount').fill('37')
    page.evaluate("""(() => {
      const template=resetTrade('pagination-base');
      const rows=Array.from({length:45},(_,i)=>({...template,id:123456+i,getAuctionData:()=>({tradeId:'page-trade-'+i,buyNowPrice:1000-i*10})}));
      window.__testPages=[rows.slice(0,21),rows.slice(20,41),rows.slice(40)];window.__testPageRequests=[];window.__testDelay=400;
    })()""")
    before=page.evaluate('({cache:__testCacheClears,bids:__bidCalls})')
    sh.locator('#scanMarket').click()
    offset=sh.locator('#cycleRing').evaluate('(e)=>e.style.strokeDashoffset')
    page.wait_for_function('(old)=>document.querySelector("#gpts-v3-host").shadowRoot.querySelector("#cycleRing").style.strokeDashoffset!==old',arg=offset)
    sh.locator('.market-card').nth(36).wait_for()
    assert sh.locator('.market-card').count()==37
    assert sh.locator('#lowestPriceValue').inner_text()=='640 Coins'
    assert page.evaluate('__testPageRequests')==[1,2]
    assert page.evaluate('__testCacheClears')==before['cache']+3 and page.evaluate('__bidCalls')==before['bids']
    assert '37/37' in sh.locator('#marketResponse').inner_text()
    assert 'market-full' not in sh.locator('#marketPanel').get_attribute('class')
    sh.locator('#marketFull').click()
    assert 'market-full' in sh.locator('#marketPanel').get_attribute('class')
    dock=sh.locator('#runDock').bounding_box();market=sh.locator('#marketPanel').bounding_box()
    assert market['y']+market['height']<=dock['y'] and sh.locator('#dockScan').is_visible()
    assert sh.locator('#start').evaluate('(e)=>e.getRootNode().elementFromPoint(e.getBoundingClientRect().x+10,e.getBoundingClientRect().y+10)===e')
    assert sh.locator('.market-card').first.locator('.market-portrait img').count()==1
    assert sh.locator('.market-card[data-trade-id="page-trade-20"]').count()==1
    page.screenshot(path='/tmp/CODEX_SNIPE_v3.7.0_market_full.png')
    sh.locator('#marketFull').click()
    old_response=sh.locator('#marketResponse').inner_text()
    sh.locator('#scanMarket').click()
    page.wait_for_function('(old)=>{const s=document.querySelector("#gpts-v3-host").shadowRoot;return !s.querySelector("#resultsCount").disabled&&s.querySelector("#marketResponse").textContent!==old;}',arg=old_response)
    assert sh.locator('.market-card').count()==37
    assert 'نفس العروض' in sh.locator('#marketResponse').inner_text()
    page.evaluate('window.__testPages=[[]]')
    sh.locator('#scanMarket').click()
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return !s.querySelector('#resultsCount').disabled&&s.querySelector('#marketResponse').textContent.includes('0/37');}")
    assert sh.locator('.market-card').count()==0 and sh.locator('#lowestPriceValue').inner_text()=='—'
    assert 'لا توجد عروض' in sh.locator('#nativeOffers').inner_text()
    # Change filters while the native controller is the result screen.
    sh.locator('[data-native-picker="quality"]').click();sh.locator('.native-option').filter(has_text='Gold').wait_for()
    assert page.evaluate('__nav.currentController instanceof UTMarketSearchFiltersViewController')
    print('PASS: manual scan makes fresh requests, paginates 37 real rows, deduplicates sentinel, updates minimum, reports repeated offers, clears on empty, reconnects pickers')

    # Cancel during native pagination: no partial batch is exposed as a completed scan.
    sh.locator('#resultsCount').fill('100')
    page.evaluate("""(() => {
      const item=resetTrade('cancel-page');
      const rows=Array.from({length:41},(_,i)=>({...item,id:123456+i,getAuctionData:()=>({tradeId:'cancel-page-'+i,buyNowPrice:900})}));
      window.__testPages=[rows.slice(0,21),rows.slice(20,41),rows.slice(40)];window.__testPageRequests=[];window.__testDelay=500;
    })()""")
    sh.locator('#scanMarket').click();page.wait_for_function('__testPageRequests.includes(2)');sh.locator('#stop').click();page.wait_for_timeout(700)
    assert sh.locator('.market-card').count()==0 and sh.locator('#lowestPriceValue').inner_text()=='—'
    assert page.evaluate('__testPageRequests')==[1,2] and page.evaluate('__testObservers.size')==0
    sh.locator('#resultsCount').fill('20')
    print('PASS: Stop during pagination detaches the observer, clears partial results and prevents the next page')

    # Selected external source drives the cap; the native Max Buy Now remains a hard ceiling.
    page.evaluate('window.__testPages=undefined;window.__testDelay=50;window.__testItems=[]')
    mock_prices="""window.__priceCalls=[];chrome.runtime.sendMessage=async m=>{window.__priceCalls.push(m);if(window.__priceFail)return {ok:false,error:'provider unavailable test',status:window.__priceStatus||null};const p=m.payload;return {ok:true,result:{quotes:[{provider:p.provider,platform:p.platform,itemId:p.ids[0],price:1200,retrievedAt:Date.now(),providerUpdatedAt:null}]}};};"""
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':mock_prices})
    assert sh.locator('#priceControls').get_attribute('open') is None
    sh.locator('#priceControls > summary').click()
    sh.locator('#loadEditions').click();sh.locator('#priceEdition option[value="50540979"]').wait_for(state='attached')
    sh.locator('#priceEdition').select_option('50540979');page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#priceEdition').disabled");sh.locator('#priceSource').select_option('futbin');sh.locator('#pricePlatform').select_option('pc');sh.locator('#pricePercent').fill('75')
    sh.locator('#maxSearches').fill('1');sh.locator('#start').click()
    page.wait_for_function('window.__nativeMaxBin===900')
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start').disabled")
    assert 'FUTBIN' in sh.locator('#quoteBox').inner_text() and '1,200' in sh.locator('#quoteBox').inner_text()
    sh.locator('#priceControls > summary').click()
    assert sh.locator('#priceControls').get_attribute('open') is None
    assert sh.locator('#priceSource').input_value()=='futbin' and sh.locator('#itemId').input_value()=='50540979'
    sh.locator('#priceControls > summary').click()
    assert sh.locator('#maxBin').input_value()=='1000'
    baseline=page.evaluate('__testSearches')
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__priceFail=true'})
    sh.locator('#start').click();page.wait_for_timeout(250)
    assert page.evaluate('__testSearches')==baseline
    assert 'provider unavailable test' in sh.locator('#logs').inner_text()
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__priceStatus=403'})
    sh.locator('#priceControls > summary').click()
    baseline=page.evaluate('__testSearches')
    sh.locator('#start').click()
    sh.locator('#priceControls[open]').wait_for(state='attached')
    assert '403' in sh.locator('#logs').inner_text() and page.evaluate('__testSearches')==baseline
    assert sh.locator('#priceSource').input_value()=='futbin'
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__priceFail=false;window.__priceStatus=0'})
    sh.locator('#priceSource').select_option('manual');sh.locator('#itemId').fill('');sh.locator('#pricePercent').fill('100')
    print('PASS: exact-edition/PC provider quote sets effective search cap, manual Max Buy Now stays intact, provider failure prevents starting')

    # MAIN rejects stale/wrong-edition quotes and limits renewed quotes to the hard Max Buy Now.
    snap=request('connect')['result']['snapshot']
    fresh_quote={'provider':'futbin','platform':'pc','itemId':50540979,'price':1200,'retrievedAt':page.evaluate('Date.now()')}
    session_args={'criteriaKey':snap['criteriaKey'],'maxPrice':900,'hardMaxPrice':1000,'maxSpend':10000,'maxBuys':1,'autoBuy':True,'itemId':50540979,'referenceQuote':fresh_quote,'referencePrice':1200}
    assert request('beginSession',{**session_args,'referenceQuote':{**fresh_quote,'retrievedAt':fresh_quote['retrievedAt']-100000}})['code']=='QUOTE_STALE'
    session_id=request('beginSession',session_args)['result']['sessionId']
    assert request('updateQuote',{'sessionId':session_id,'quote':fresh_quote,'maxPrice':1100})['code']=='LIMIT'
    assert request('updateQuote',{'sessionId':session_id,'quote':{**fresh_quote,'platform':'console'},'maxPrice':900})['code']=='QUOTE_STALE'
    assert request('updateQuote',{'sessionId':session_id,'quote':{**fresh_quote,'itemId':209331},'maxPrice':900})['code']=='QUOTE_STALE'
    assert request('updateQuote',{'sessionId':session_id,'quote':fresh_quote,'maxPrice':950})['ok']
    request('cancel')
    print('PASS: MAIN quote freshness, exact edition/platform and immutable hard price ceiling on renewal')

    # Native post-purchase moves preserve the confirmed receipt on failure.
    for destination,failed in [('club',False),('transfer',False),('club',True),('leave',False)]:
        page.evaluate("""([destination,failed])=>{resetTrade('move-'+destination+'-'+failed);window.__bidScenario='won';window.__moveFailed=failed;}""",[destination,failed])
        before=page.evaluate('({bids:__bidCalls,moves:__moveCalls})')
        sh.locator('#postPurchase').select_option(destination);sh.locator('#autoBuy').check();sh.locator('#start').click()
        page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#buyCount').textContent==='1'&&!s.querySelector('#start').disabled;}")
        assert page.evaluate('__bidCalls')==before['bids']+1 and sh.locator('#spent').inner_text()=='900'
        assert page.evaluate('__moveCalls')==before['moves']+(0 if destination=='leave' else 1)
        if destination!='leave':assert page.evaluate('__lastMovePile')==({'club':1,'transfer':2}[destination])
        if failed:assert 'النقل لم يتأكد' in sh.locator('#logs').inner_text()
    sh.locator('#postPurchase').select_option('leave');sh.locator('#autoBuy').uncheck()
    print('PASS: original EA action move sends confirmed item to Club/Transfer List, leave performs no move, failed move never retries or erases purchase')

    # Repeated clicks queue one fresh scan, never overlap requests or append prior cards.
    sh.locator('#autoBuy').uncheck();sh.locator('#resultsCount').fill('20')
    page.evaluate("window.__testItems=[];window.__testPages=undefined;window.__testDelay=350;window.__requestsMax=0;window.__searchedPlayers=[]")
    before=page.evaluate('__testSearches')
    sh.locator('#scanMarket').click();sh.locator('#scanMarket').click();sh.locator('#scanMarket').click();sh.locator('#scanMarket').click()
    page.wait_for_function('(before)=>__testSearches===before+2',arg=before)
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert page.evaluate('__requestsMax')==1 and sh.locator('.market-card').count()==0
    assert 'market-full' not in sh.locator('#marketPanel').get_attribute('class')
    assert page.evaluate('__nativeMinBid')==0 and page.evaluate('__nativeMaxBid===0||__nativeMaxBid>=__nativeMaxBin')
    assert sh.locator('#maxBid').input_value()==''
    print('PASS: rapid clicks coalesce to one additional fresh request, no overlap, no bid-filter mutation, no stale card accumulation')

    # Stable workspace layout, positions and pinned multi-player cards.
    assert sh.locator('[data-panel-key="players"] #transferSection #priceSource').count()==1
    event=sh.locator('[data-native-picker="event"]').bounding_box();quality=sh.locator('[data-native-picker="quality"]').bounding_box()
    item=sh.locator('#itemId').bounding_box();low=sh.locator('#ratingMin').bounding_box();high=sh.locator('#ratingMax').bounding_box()
    assert abs(event['y']-quality['y'])<2 and item['y']>event['y'] and low['y']>item['y'] and abs(low['y']-high['y'])<2
    assert sh.locator('.column.right > [data-panel-key="logs"] + [data-panel-key="connection"]').count()==1
    sh.locator('#editLayout').click()
    original_cap=sh.locator('#maxBin').input_value()
    sh.locator('[data-panel-key="stats"] > .panel-head [data-move="column"]').click()
    assert sh.locator('.column.control > [data-panel-key="stats"]').count()==1
    sh.locator('#resetLayout').click()
    assert sh.locator('.column.right > [data-panel-key="stats"]').count()==1 and sh.locator('#maxBin').input_value()==original_cap
    sh.locator('#editLayout').click()
    sh.locator('#addPlayer').click()
    page.evaluate('window.__duplicatePlayers=true')
    sh.locator('#player').fill('Salah');sh.locator('#playerResults .result').first.wait_for()
    assert sh.locator('#playerResults .result').count()==1 and 'RW' in sh.locator('#playerResults .result').first.inner_text()
    page.evaluate('window.__duplicatePlayers=false')
    sh.locator('#player').fill('son');sh.locator('#playerResults .result').filter(has_text='Son Heungmin').wait_for()
    sh.locator('#playerResults .result').filter(has_text='Son Heungmin').click()
    page.wait_for_function("__nav.currentController.viewmodel.searchCriteria.maskedDefId===200104")
    assert sh.locator('#selectedTargets .selected-card').count()==2 and sh.locator('#playerSearchDrawer').is_hidden()
    assert sh.locator('.selected-card[data-player-id="200104"] img').count()==1
    assert 'LW' in sh.locator('.selected-card[data-player-id="200104"]').inner_text()
    sh.locator('.selected-card[data-player-id="209331"] .target-card-select').click()
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return !s.querySelector('#start').disabled&&__nav.currentController.viewmodel?.searchCriteria.maskedDefId===209331;}")
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.rarities')==[12]
    sh.locator('.selected-card[data-player-id="200104"] .target-card-select').click()
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start').disabled&&__nav.currentController.viewmodel?.searchCriteria.maskedDefId===200104")
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.rarities')==[]
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=0')
    page.screenshot(path='/tmp/CODEX_SNIPE_v3.8.0_targets.png')
    print('PASS: combined player/transfer panels, pricing placement, connection below logs, reversible panel ordering, native positions, duplicate player IDs removed, pinned cards and collapsed picker')

    # A two-player run preserves a single budget ledger. A second 900 purchase cannot fit 1500 total.
    page.evaluate('window.__autoTargetOffers=true;window.__searchedPlayers=[];window.__testDelay=120;window.__testItems=[]')
    sh.locator('#speedPreset').select_option('custom');sh.locator('#speedMin').fill('0.6');sh.locator('#speedMax').fill('0.6')
    sh.locator('#maxSearches').fill('4');sh.locator('#maxBuys').fill('2');sh.locator('#budget').fill('1500');sh.locator('#autoBuy').check()
    calls=page.evaluate('__bidCalls');sh.locator('#start').click()
    page.wait_for_function("()=>document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#searchCount').textContent==='1'")
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__savedTradeHelper=window.CodexTradeCore;delete window.CodexTradeCore;'})
    page.wait_for_timeout(250)
    assert len(sh.locator('#time').inner_text().split(':'))==3 and sh.locator('#cyclePhase').inner_text()!='—'
    angle=sh.locator('#gaugeRotor').evaluate('(e)=>getComputedStyle(e).transform')
    page.wait_for_function('(angle)=>getComputedStyle(document.querySelector("#gpts-v3-host").shadowRoot.querySelector("#gaugeRotor")).transform!==angle',arg=angle)
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#searchCount').textContent==='4'&&!s.querySelector('#start').disabled;}",timeout=12000)
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.CodexTradeCore=window.__savedTradeHelper;'})
    assert page.evaluate('__searchedPlayers')==[209331,200104,209331,200104]
    assert page.evaluate('__bidCalls')==calls+1 and sh.locator('#buyCount').inner_text()=='1' and sh.locator('#spent').inner_text()=='900'
    assert sh.locator('#gaugeRotor').evaluate('(e)=>e.style.animationPlayState')=='paused'
    # With enough budget both players can be purchased, still in one session.
    page.evaluate('window.__searchedPlayers=[]')
    sh.locator('#budget').fill('2000');sh.locator('#maxSearches').fill('2');calls=page.evaluate('__bidCalls');sh.locator('#start').click()
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#buyCount').textContent==='2'&&!s.querySelector('#start').disabled;}",timeout=12000)
    assert page.evaluate('__searchedPlayers')==[209331,200104] and page.evaluate('__bidCalls')==calls+2
    assert sh.locator('#spent').inner_text()=='1,800' and sh.locator('.outcome-toast.won').count()>=1
    assert 'LW' in sh.locator('.market-card').first.inner_text()
    print('PASS: native round-robin target selection, exact ID/rarity checks, one budget/purchase ledger across players, rotor animates during run and pauses at stop, confirmed-purchase toasts')
    page.evaluate('window.__autoTargetOffers=false;window.__testDelay=50')
    sh.locator('.selected-card[data-player-id="200104"] > .target-remove').click()
    page.wait_for_function('__nav.currentController.viewmodel?.searchCriteria.maskedDefId===209331')
    assert sh.locator('.selected-card').count()==1
    sh.locator('#maxBuys').fill('1');sh.locator('#maxSearches').fill('1');sh.locator('#budget').fill('10000')

    # Smart ladder sends distinct bid constraints strictly above Buy Now while preserving the purchase ceiling and native filters.
    sh.locator('#searchRoute').select_option('sdk')
    sh.locator('#autoBuy').uncheck();sh.locator('#maxBin').fill('1500');sh.locator('#bidLadder').select_option('smartMaxBid');sh.locator('#bidLadderCeiling').fill('1900')
    page.evaluate('window.__testItems=[];window.__sdkCalls=[]')
    for _ in range(5):
        sh.locator('#scanMarket').click()
        page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert page.evaluate('__sdkCalls.map(x=>x.maxBid)')==[1600,1700,1800,1900,0]
    assert page.evaluate('__sdkCalls.map(x=>x.minBid)')==[0]*5 and page.evaluate('__sdkCalls.every(x=>x.maxBuy===1500)')
    ladder_logs=sh.locator('#logs .log-row p').all_text_contents()
    ladder_logs=[x for x in ladder_logs if 'إرسال فحص السوق' in x][:5][::-1]
    assert len(ladder_logs)==5
    for index,(entry,value) in enumerate(zip(ladder_logs,[1600,1700,1800,1900,0])):
      maximum=f'{value:,}' if value else 'بدون حد (0)'
      assert f'خطوة {index+1}/5' in entry and 'Min Bid: 0' in entry and f'Max Bid: {maximum}' in entry and 'Max Buy Now: 1,500' in entry
    assert sh.locator('#maxBid').input_value()==''
    sh.locator('#bidLadder').select_option('off');sh.locator('#scanMarket').click()
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert page.evaluate('__sdkCalls.at(-1).maxBid')==0
    fixed_log=sh.locator('#logs .log-row p').filter(has_text='إرسال فحص السوق').first.inner_text()
    assert 'السلم متوقف' in fixed_log and 'خطوة' not in fixed_log and 'Max Bid: بدون حد (0)' in fixed_log
    print('PASS: each dispatched scan logs its actual prepared bid/BIN values, 1-based ladder step, uncapped round and fixed mode without a stale step')
    sh.locator('#bidLadder').select_option('smartMaxBid');sh.locator('#bidLadderCeiling').fill('200000');page.evaluate('window.__sdkCalls=[]')
    for _ in range(7):
        sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert page.evaluate('__sdkCalls.map(x=>x.maxBid)')==[1600,1700,1800,1900,2000,2100,2200]
    sh.locator('#bidLadder').select_option('off')
    print('PASS: short and 200k native Max Bid ladders, no premature wrap, fixed Min Bid and Buy Now ceiling, reversible fixed-bid mode')

    sh.locator('#searchRoute').select_option('screen')
    sh.locator('#sync').click();page.wait_for_function('__nativeMaxBin===1500')
    # A layout wrapper may change while the actual native results controller stays the same.
    page.evaluate("resetTrade('same-inner-controller');window.__testDelay=350")
    sh.locator('#scanMarket').click()
    page.wait_for_function('__nav.currentController instanceof UTMarketSearchResultsSplitViewController')
    page.evaluate('__nav.currentController=__nav.currentController._listController')
    sh.locator('.market-card[data-trade-id="same-inner-controller"]').wait_for()
    assert 'RW' in sh.locator('.market-card').first.inner_text()
    assert sh.locator('.market-position').first.inner_text()=='RW'
    print('PASS: same native result controller survives wrapper changes without a false VIEW_CHANGED error')

    # An awaited navigation command cannot pop a running search; cancellation stops a pending navigation too.
    page.evaluate('__nav.isTransitioning=true')
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':"window.__pendingNav=GPTPageClient.request('connect').then(r=>({ok:true}),e=>({ok:false,code:e.code}));"})
    page.wait_for_timeout(100)
    assert request('status')['result']['busy'] is True
    assert request('search',{'maxBin':1500,'criteriaKey':'unused'})['code']=='BUSY'
    request('cancel')
    pending=cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__pendingNav','awaitPromise':True,'returnByValue':True})
    assert pending['result']['value']['code']=='CANCELLED'
    page.evaluate('__nav.isTransitioning=false')
    assert request('connect')['ok']
    # A genuine Back/navigation is still rejected and never turns old rows into new results.
    sh.locator('#scanMarket').click();page.wait_for_function('__nav.currentController instanceof UTMarketSearchResultsSplitViewController')
    page.evaluate('__nav.popToViewController(__nav.childViewControllers.find(c=>c instanceof UTMarketSearchFiltersViewController))')
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==0 and 'EA closed or changed' in sh.locator('#marketResponse').inner_text()
    page.wait_for_timeout(400);page.evaluate('window.__testDelay=50;window.__testItems=[]')
    print('PASS: native operation lock prevents overlapping navigation/search, cancellation stops pending navigation, real view changes clear current rows')

    # Hide intro reclaims vertical space; presets restore native filter IDs and targets, not just labels.
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=0')
    old_y=sh.locator('.layout').evaluate('(e)=>e.offsetTop')
    sh.locator('#toggleIntro').click()
    assert sh.locator('.intro').is_hidden()
    new_y=sh.locator('.layout').evaluate('(e)=>e.offsetTop')
    assert new_y<old_y
    sh.locator('#toggleIntro').click();assert sh.locator('.intro').is_visible()
    page.remove_listener('dialog',dialog_handler)
    page.once('dialog',lambda d:d.accept('Native saved filter'))
    sh.locator('#maxBin').fill('1000');sh.locator('#saveFilterTop').click()
    sh.locator('#presets option[value="Native saved filter"]').wait_for(state='attached')
    page.on('dialog',dialog_handler)
    sh.locator('#clearTargets').click();page.wait_for_function('__nav.currentController.viewmodel?.searchCriteria.maskedDefId===0')
    sh.locator('#maxBin').fill('700');sh.locator('#presets').select_option('Native saved filter')
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return !s.querySelector('#start').disabled&&__nav.currentController.viewmodel?.searchCriteria.maskedDefId===209331;}")
    assert sh.locator('#maxBin').input_value()=='1000' and page.evaluate('__nativeMaxBin')==1000
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.rarities')==[12]
    assert sh.locator('.selected-card').count()==1 and sh.locator('#playerSearchDrawer').is_hidden()
    # The same save action must restore generic GK/nation filters with no selected player.
    sh.locator('#clearTargets').click();page.wait_for_function('__nav.currentController.viewmodel?.searchCriteria.maskedDefId===0')
    sh.locator('[data-native-picker="position"]').click();sh.locator('.native-option').filter(has_text='GK').click()
    sh.locator('[data-native-picker="nation"]').click();sh.locator('.native-option').filter(has_text='Spain').click()
    page.remove_listener('dialog',dialog_handler);page.once('dialog',lambda d:d.accept('Spanish keepers'))
    sh.locator('#saveFilterTop').click();sh.locator('#presets option[value="Spanish keepers"]').wait_for(state='attached')
    page.on('dialog',dialog_handler)
    sh.locator('[data-native-picker="position"]').click();sh.locator('.native-option').filter(has_text='Any position').click()
    sh.locator('[data-native-picker="nation"]').click();sh.locator('.native-option').filter(has_text='Any nation').click()
    sh.locator('#presets').select_option('Spanish keepers')
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start').disabled&&__nav.currentController.viewmodel?.searchCriteria.nation===45")
    assert page.evaluate('__nav.currentController.viewmodel.searchCriteria.position')=='GK'
    assert sh.locator('.selected-card').count()==0 and sh.locator('#maxBin').input_value()=='1000'
    sh.locator('#presets').select_option('Native saved filter')
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start').disabled&&__nav.currentController.viewmodel?.searchCriteria.maskedDefId===209331")
    badge=sh.locator('.selected-portrait .position-badge').first.bounding_box();rating=sh.locator('.selected-portrait > b').first.bounding_box()
    assert badge['y']>rating['y'] and abs(badge['x']-rating['x'])<20
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=800');sh.locator('#scrollTop').wait_for();sh.locator('#scrollTop').click()
    page.wait_for_function("()=>document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#shell').scrollTop<5")
    page.screenshot(path='/tmp/CODEX_SNIPE_v3.8.0_compact.png')
    print('PASS: intro toggle reclaims space, header filter save/load restores native IDs/player/prices, card position sits under rating, floating Top scrolls the dashboard')

    # Clicking the same native picker closes its choices without changing the selected filter.
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=0')
    dock_top=sh.locator('#start').bounding_box()['y']
    sh.locator('#shell').evaluate('(e)=>e.scrollTop=e.scrollHeight')
    page.wait_for_timeout(80)
    assert abs(sh.locator('#start').bounding_box()['y']-dock_top)<1
    assert sh.locator('#stop').is_visible() and sh.locator('#dockScan').is_visible()
    sh.locator('#language').select_option('en')
    assert sh.locator('#runDock').count()==1 and sh.locator('#start').count()==1 and sh.locator('#dockScan').inner_text()=='Scan market'
    sh.locator('#language').select_option('ar')
    page.set_viewport_size({'width':600,'height':800})
    page.wait_for_timeout(80)
    for action in ['start','stop','savePreset','dockScan']:
      rect=sh.locator('#'+action).bounding_box()
      assert rect['x']>=0 and rect['y']>=0 and rect['x']+rect['width']<=600 and rect['y']+rect['height']<=800
    page.set_viewport_size({'width':1500,'height':1000})
    print('PASS: persistent dock retains visible Start/Stop/Scan on shell scroll and full results, fits small screens, and rebuilds once across language changes')

    sh.locator('[data-native-picker="position"]').click();sh.locator('.native-option').first.wait_for()
    field=sh.locator('[data-native-picker="position"]').bounding_box();menu=sh.locator('#nativePickerArea').bounding_box()
    assert abs(menu['x']-field['x'])<2 and abs(menu['width']-field['width'])<2
    assert abs(menu['y']-(field['y']+field['height']+5))<2 or abs(menu['y']+menu['height']+5-field['y'])<2
    one=sh.locator('.native-option').nth(0).bounding_box();two=sh.locator('.native-option').nth(1).bounding_box()
    assert abs(one['x']-two['x'])<1 and two['y']>=one['y']+one['height']
    unchanged=sh.locator('#transferSection').bounding_box()['height']
    page.screenshot(path='/tmp/CODEX_SNIPE_v3.9.0_anchored_filters.png')
    before=request('readFilters')['result']['criteriaKey']
    sh.locator('[data-native-picker="position"]').click()
    assert sh.locator('#nativePickerArea').is_hidden() and sh.locator('[data-native-picker="position"]').get_attribute('aria-expanded')=='false'
    assert abs(sh.locator('#transferSection').bounding_box()['height']-unchanged)<1
    assert request('readFilters')['result']['criteriaKey']==before
    sh.locator('[data-native-picker="position"]').click();sh.locator('.native-option').first.wait_for()
    sh.locator('.native-option-filter').focus();page.keyboard.press('Escape')
    assert sh.locator('#nativePickerArea').is_hidden()
    sh.locator('[data-native-picker="position"]').click();sh.locator('.native-option').filter(has_text='RW').click()
    sh.locator('#nativePickerArea').wait_for(state='hidden')
    assert sh.locator('#nativePickerArea').is_hidden()
    print('PASS: native filter choices toggle closed on a second click and after selection, preserving original IDs')

    # Reproduce the native view's Max Bid / Max Buy Now linkage using its original source method.
    request('connect')
    page.evaluate("""(() => {
      const c=__nav.currentController,v=c.getView();window.__realPriceView=v;
      window.__oldMaxBuySetter=v.setMaxBuyNowPrice;window.__oldMaxBidSetter=v.setMaxBidPrice;
      v.setMaxBidPrice=value=>{window.__oldMaxBidSetter(value);c.eMaxBidPriceChanged(null,null,{value});};
      v.setMaxBuyNowPrice=function(value){
        window.__oldMaxBuySetter(value);this._maxBidPriceRow={value:c.viewmodel.searchCriteria.maxBid};this._minBuyNowPriceRow={value:c.viewmodel.searchCriteria.minBuy};this._maxBuyNowPriceRow={value};this._clearBuyPrice={setInteractionState:()=>{}};
        this._triggerActions=(_event,data)=>c.eMaxBuyPriceChanged(null,null,data);
        UTMarketSearchFiltersView.prototype.eMaxBuyPriceChanged.call(this,null,null,{delta:0});
      };
    })()""")
    linked=request('applyPrices',{'minBid':0,'maxBid':200000,'minBin':0,'maxBin':7000})
    assert linked['code']=='PRICE_MISMATCH'
    assert request('readFilters')['result']['prices']['maxBid']==6900
    print('PASS: original EA view coupling reduces Max Bid 200000 to 6900 at Buy Now 7000; final validation rejects the silent rewrite')

    # SDK query clones native category filters and holds independent bid/BIN values while the native screen remains unchanged.
    sh.locator('#searchRoute').select_option('sdk');sh.locator('#bidLadder').select_option('smartMaxBid');sh.locator('#bidLadderCeiling').fill('200000');sh.locator('#maxBin').fill('7000')
    page.evaluate("window.__testItems=[];window.__testPages=undefined;window.__sdkCalls=[];window.__testDelay=150")
    for _ in range(3):
      sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert page.evaluate('__sdkCalls.map(x=>x.maxBid)')==[7100,7200,7300]
    assert page.evaluate('__sdkCalls.every(x=>x.maxBuy===7000)')
    assert request('readFilters')['result']['prices']['maxBid']==6900
    assert page.evaluate('__nav.currentController instanceof UTMarketSearchFiltersViewController')
    assert 'EA SDK' in sh.locator('#marketResponse').inner_text()
    assert page.evaluate('__sdkMaxInFlight')==1
    print('PASS: SDK route sends increasing Max Bid with fixed Max Buy Now, bypasses view-field coupling, keeps the native screen stable and serializes requests')

    # All three options belong to the original CODEX UI and reach its cloned SDK query.
    for ladder_mode,field,expected in [('minBid','minBid',[0,150]),('maxBid','maxBid',[0,150])]:
      sh.locator('#bidLadder').select_option(ladder_mode)
      assert sh.locator('#bidLadderCeiling').is_disabled()
      page.evaluate('window.__sdkCalls=[]')
      before_clears=page.evaluate('__testCacheClears')
      for _ in range(2):
        sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
      assert page.evaluate('__sdkCalls.map(x=>x.'+field+')')==expected
      assert page.evaluate('__sdkCalls.every(x=>x.maxBuy===7000)')
      assert page.evaluate('__testCacheClears')==before_clears+2
      assert request('readFilters')['result']['prices']['maxBid']==6900
    sh.locator('#bidLadder').select_option('smartMaxBid')
    assert not sh.locator('#bidLadderCeiling').is_disabled()
    print('PASS: Min Bid, regular Max Bid and smart Max Bid are distinct choices in the original themed workspace, with local eviction per scan and no native screen-price mutation')

    # Real same-auction repeats remain visible and are labelled by Trade ID comparison, not random substitutions.
    page.evaluate("resetTrade('sdk-same-offer')")
    sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==1 and sh.locator('.market-card').first.get_attribute('data-trade-id')=='sdk-same-offer'
    assert 'نفس العروض' in sh.locator('#marketResponse').inner_text() and 'أرقام جديدة مقارنة بآخر رد: 0' in sh.locator('#marketResponse').inner_text()
    assert sh.locator('.trade-history[data-seen="true"]').count()==1
    page.evaluate('window.__testItems=[]');sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==0 and sh.locator('#lowestPriceValue').inner_text()=='—'
    page.evaluate('window.__sdkError=429');before=page.evaluate('__sdkCalls.length')
    sh.locator('#scanMarket').click();sh.locator('#scanMarket').click()
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert '429' in sh.locator('#marketResponse').inner_text() and page.evaluate('__sdkCalls.length')==before+1
    page.evaluate('window.__sdkError=0')
    print('PASS: SDK repeated/empty responses are truthful, minimum clears, HTTP-style 429 stops the queued refresh without retrying')

    # SDK pagination deduplicates native sentinels and cancellation never exposes a partial batch.
    page.evaluate("""(() => {
      const source=resetTrade('sdk-page-template');const rows=Array.from({length:45},(_,i)=>({...source,id:300000+i,getAuctionData:()=>({tradeId:'sdk-page-'+i,buyNowPrice:900+i})}));
      window.__testPages=[rows.slice(0,21),rows.slice(20,41),rows.slice(40)];window.__sdkCalls=[];window.__testDelay=150;
    })()""")
    sh.locator('#resultsCount').fill('37');sh.locator('#scanMarket').click()
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==37 and sh.locator('.market-card[data-trade-id="sdk-page-20"]').count()==1
    assert page.evaluate('__sdkCalls.map(x=>[x.page,x.count,x.offset])')==[[1,21,0],[2,21,20]]
    assert sh.locator('#lowestPriceValue').inner_text()=='900 Coins'
    page.evaluate('window.__testDelay=350;window.__sdkCalls=[]')
    sh.locator('#resultsCount').fill('100');sh.locator('#scanMarket').click();page.wait_for_function('__sdkCalls.length===2');sh.locator('#stop').click()
    page.wait_for_timeout(450)
    assert page.evaluate('__sdkCalls.length')==2 and sh.locator('.market-card').count()==0
    assert page.evaluate('__testObservers.size')==0
    page.evaluate('window.__testPages=undefined;window.__testDelay=50');sh.locator('#resultsCount').fill('20')
    print('PASS: SDK pagination preserves count/offset, deduplicates sentinels, computes the minimum, and Stop discards partial results')

    sh.locator('#maxBin').fill('1000');sh.locator('#bidLadder').select_option('smartMaxBid');sh.locator('#autoBuy').check();sh.locator('#maxBuys').fill('1');sh.locator('#maxSearches').fill('1')
    page.evaluate("resetTrade('sdk-gui-buy');window.__bidScenario='won'")
    before=page.evaluate('__bidCalls');sh.locator('#start').click()
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#buyCount').textContent==='1'&&!s.querySelector('#start').disabled;}")
    assert page.evaluate('__bidCalls')==before+1 and sh.locator('#spent').inner_text()=='900'
    assert page.evaluate('__nav.currentController instanceof UTMarketSearchFiltersViewController')
    assert page.evaluate('__sdkCalls.at(-1).maxBuy')==1000 and page.evaluate('__lastBidPrice')==900
    assert 'EA SDK DIRECT CONNECTED' in sh.locator('#connection').inner_text()
    snipe_log=sh.locator('#logs .log-row p').filter(has_text='إرسال بحث السنايب').first.inner_text()
    assert 'سلم Smart Max Bid' in snipe_log and 'Min Bid: 0' in snipe_log and 'Max Buy Now: 1,000' in snipe_log
    sh.locator('#autoBuy').uncheck()
    print('PASS: full UI Auto Buy uses SDK directly with view linkage active, original native item, actual Buy Now price, confirmed counters and no results-controller navigation')

    for ladder_mode in ['minBid','maxBid']:
      sh.locator('#bidLadder').select_option(ladder_mode);sh.locator('#autoBuy').check()
      page.evaluate("resetTrade('codex-ladder-buy-"+ladder_mode+"')")
      before=page.evaluate('__bidCalls');sh.locator('#start').click()
      page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#buyCount').textContent==='1'&&!s.querySelector('#start').disabled;}")
      assert page.evaluate('__bidCalls')==before+1 and page.evaluate('__lastBidPrice')==900
      assert page.evaluate('__sdkCalls.at(-1).maxBuy')==1000 and sh.locator('#spent').inner_text()=='900'
      sh.locator('#autoBuy').uncheck()
    print('PASS: original CODEX purchase receipts and budget guards also work with the optional Min Bid and regular Max Bid ladders')

    # SDK plan integrity and the purchase guard operate on the real native item object without a results-view controller.
    sh.locator('#maxBin').fill('1000');sh.locator('#bidLadder').select_option('off')
    snap=request('connect')['result']['snapshot']
    plan=request('prepareSearch',{'criteriaKey':snap['criteriaKey'],'prices':{'minBid':0,'maxBid':200000,'minBin':0,'maxBin':1000}})['result']
    assert request('search',{'route':'sdk','planId':-1,'maxBin':1000,'criteriaKey':snap['criteriaKey']})['code']=='STALE_PLAN'
    session_id=request('beginSession',{'route':'sdk','planId':plan['planId'],'criteriaKey':snap['criteriaKey'],'maxPrice':1000,'maxSpend':1500,'maxBuys':2,'autoBuy':True})['result']['sessionId']
    page.evaluate("resetTrade('sdk-native-buy');window.__bidScenario='won'")
    result=request('search',{'route':'sdk','planId':plan['planId'],'maxBin':1000,'criteriaKey':snap['criteriaKey'],'limit':5})['result']
    calls=page.evaluate('__bidCalls')
    bought=request('buy',{'sessionId':session_id,'searchId':result['searchId'],'tradeId':'sdk-native-buy','instanceId':'123456','expectedPrice':900})
    assert bought['result']['status']=='bought' and bought['result']['spent']==900 and page.evaluate('__bidCalls')==calls+1
    assert page.evaluate('__lastBidItem===__testItems[0]') and page.evaluate('__nav.currentController instanceof UTMarketSearchFiltersViewController')
    page.evaluate("resetTrade('sdk-budget-second')")
    result=request('search',{'route':'sdk','planId':plan['planId'],'maxBin':1000,'criteriaKey':snap['criteriaKey'],'limit':5})['result']
    assert request('buy',{'sessionId':session_id,'searchId':result['searchId'],'tradeId':'sdk-budget-second','instanceId':'123456','expectedPrice':900})['code']=='LIMIT'
    request('cancel')
    page.evaluate('window.__realPriceView.setMaxBuyNowPrice=window.__oldMaxBuySetter;window.__realPriceView.setMaxBidPrice=window.__oldMaxBidSetter;')
    sh.locator('#searchRoute').select_option('screen')
    print('PASS: SDK plan/identity validation, original native bid object, confirmed receipt and unchanged shared budget enforcement')

    # Theme changes move existing UI nodes, keep per-theme arrangements, and persist without changing filters.
    page.evaluate("window.__themeStartNode=document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start')")
    cdp.send('Runtime.evaluate',{'contextId':world,'expression':'chrome.storage.local.set=async value=>{window.__lastThemeWrite=value;};'})
    item_value=sh.locator('#itemId').input_value();price_value=sh.locator('#maxBin').input_value();response_caption=sh.locator('#marketResponse').inner_text()
    sh.locator('#workspaceTheme').select_option('cockpit')
    assert page.evaluate("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start')===__themeStartNode")
    assert sh.locator('.column.center [data-panel-key="stats"]').count()==1
    assert sh.locator('.column.center [data-panel-key="engine"]').count()==1
    assert sh.locator('.column.control [data-panel-key="players"]').count()==1
    assert sh.locator('.column.right [data-panel-key="logs"]').count()==1
    assert sh.locator('.column.right [data-panel-key="market"]').count()==1
    sh.locator('#editLayout').click()
    sh.locator('[data-panel-key="engine"] > .panel-head .panel-move[data-move="column"]').click()
    assert sh.locator('.column.right [data-panel-key="engine"]').count()==1
    sh.locator('#workspaceTheme').select_option('classic')
    assert sh.locator('.column.control [data-panel-key="engine"]').count()==1
    sh.locator('#workspaceTheme').select_option('cockpit')
    assert sh.locator('.column.right [data-panel-key="engine"]').count()==1
    sh.locator('#resetLayout').click()
    assert sh.locator('.column.center [data-panel-key="engine"]').count()==1
    sh.locator('#editLayout').click()
    sh.locator('#workspaceTheme').select_option('aurora')
    assert sh.locator('.column.right [data-panel-key="market"]').count()==1
    assert sh.locator('.column.control [data-panel-key="engine"]').count()==1
    assert sh.locator('.column.control > [data-panel-key]').first.get_attribute('data-panel-key')=='stats'
    sh.locator('#language').select_option('en')
    assert sh.locator('#workspaceTheme').input_value()=='aurora' and sh.locator('.column.right [data-panel-key="market"]').count()==1
    sh.locator('#language').select_option('ar')
    assert sh.locator('#marketResponse').inner_text()==response_caption
    page.evaluate("window.__themeStartNode=document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start')")
    palettes=[]
    for theme in ['classic','cockpit','aurora']:
      sh.locator('#workspaceTheme').select_option(theme)
      assert sh.locator('[data-panel-key]').count()==9 and sh.locator('#start').count()==1
      assert sh.locator('#itemId').input_value()==item_value and sh.locator('#maxBin').input_value()==price_value
      palettes.append(sh.locator('[data-panel-key="players"]').evaluate('(e)=>getComputedStyle(e).backgroundImage'))
      assert page.evaluate("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#start')===__themeStartNode") is True
      page.set_viewport_size({'width':1700,'height':1050});sh.locator('#shell').evaluate('(e)=>e.scrollTop=0')
      page.screenshot(path='/tmp/CODEX_SNIPE_v3.18.0_'+theme+'.png')
      if theme!='classic':
        left=sh.locator('.column.control').bounding_box();center=sh.locator('.column.center').bounding_box();right=sh.locator('.column.right').bounding_box()
        assert left['x']<center['x']<right['x']
      page.set_viewport_size({'width':600,'height':900})
      assert sh.locator('#shell').evaluate('(e)=>e.scrollWidth<=e.clientWidth')
      stop_box=sh.locator('#stop').bounding_box();assert stop_box['x']>=0 and stop_box['x']+stop_box['width']<=600 and stop_box['y']+stop_box['height']<=900
    assert len(set(palettes))==3
    write=cdp.send('Runtime.evaluate',{'contextId':world,'expression':'window.__lastThemeWrite.gpts_embedded_v3','returnByValue':True})['result']['value']
    assert write['workspaceTheme']=='aurora' and write['themeLayouts']['cockpit']['center']==['stats','engine']
    page.set_viewport_size({'width':1500,'height':1000});sh.locator('#workspaceTheme').select_option('classic')
    print('PASS: three distinct theme layouts/palettes, per-theme panel order/reset, persistence, language rebuild, unchanged filter values and responsive fixed controls')

    # Profile strategies share native identity/receipt guards but choose different candidates and purchase wrappers.
    page.evaluate("""() => {
      window.__originalActionBid=UTItemActionController.prototype.bid;window.__actionBidCalls=0;
      UTItemActionController.prototype.bid=function(...args){window.__actionBidCalls++;return __originalActionBid.apply(this,args);};
      window.__makeModeOffers=(prefix,count=45)=>{
        const template=resetTrade(prefix+'-template');
        const rows=Array.from({length:count},(_,i)=>{const price=i===0?900:i===1?700:i===2?800:950;
          const auction={tradeId:prefix+'-'+i,buyNowPrice:price,won:false,canBuy:coins=>!auction.won&&coins>=price,getSecondsRemaining:()=>auction.won?0:60,isWon:()=>auction.won};
          return {...template,id:800000+i,getAuctionData:()=>auction,getMarketAverage:()=>i===2?2000:1000};
        });window.__modeRows=rows;window.__testItems=rows;window.__testPages=[rows.slice(0,21),rows.slice(20,41),rows.slice(40)];window.__sdkCalls=[];return rows;
      };
      window.__testDelay=50;window.__bidScenario='won';
    }""")
    sh.locator('#resultsCount').fill('37');sh.locator('#maxBin').fill('1000');sh.locator('#budget').fill('2000')
    sh.locator('#maxBuys').fill('1');sh.locator('#maxSearches').fill('1');sh.locator('#autoBuy').uncheck()
    sh.locator('#engineMode').select_option('pharaoh')
    page.evaluate("__makeModeOffers('profile-manual')")
    sh.locator('#scanMarket').click();page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==37 and page.evaluate('__sdkCalls.length')==2
    assert sh.locator('.market-card').first.get_attribute('data-trade-id')=='profile-manual-0'
    for mode,expected,pages,action_delta in [('pharaoh',0,1,0),('deep',2,1,1),('enhancer',1,2,0)]:
      sh.locator('#engineMode').select_option(mode);page.evaluate("__makeModeOffers('profile-'+"+json.dumps(mode)+")")
      before=page.evaluate('({bid:__bidCalls,action:__actionBidCalls})');sh.locator('#autoBuy').check();
      if mode=='pharaoh':page.evaluate('window.__testDelay=1600')
      sh.locator('#start').click()
      if mode=='pharaoh':
        page.wait_for_function('__sdkCalls.length===1');sh.locator('#workspaceTheme').select_option('cockpit');sh.locator('#workspaceTheme').select_option('aurora')
        assert sh.locator('.cycle-gauge').is_hidden() and sh.locator('#digitalTrack').is_visible()
        page.wait_for_function("()=>{const a=document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#digitalProgress').getAnimations()[0];return a?.playState==='running'&&a.currentTime>0;}")
        progress_time=sh.locator('#digitalProgress').evaluate('(e)=>e.getAnimations()[0]?.currentTime')
        page.wait_for_timeout(90)
        assert sh.locator('#digitalProgress').evaluate('(e)=>e.getAnimations()[0]?.currentTime')>progress_time
      page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;return s.querySelector('#buyCount').textContent==='1'&&!s.querySelector('#start').disabled;}")
      assert page.evaluate('__bidCalls')==before['bid']+1 and page.evaluate('__actionBidCalls')==before['action']+action_delta
      assert page.evaluate('__lastBidItem===__modeRows['+str(expected)+']') and page.evaluate('__sdkCalls.length')==pages
      assert sh.locator('#spent').inner_text()==str([900,700,800][expected])
      assert sh.locator('.market-card').count()==(20 if pages==1 else 37)
      assert mode.lower() in sh.locator('#marketResponse').inner_text().lower()
    sh.locator('#workspaceTheme').select_option('classic');page.evaluate('window.__testDelay=50')
    print('PASS: all three UI modes use native EA results, preserve manual count, enforce first-page sniping where specified, choose the correct native item and confirm actual spending')

    sh.locator('#engineMode').select_option('deep');page.evaluate("__makeModeOffers('profile-stop')")
    calls=page.evaluate('__bidCalls');sh.locator('#start').click()
    page.wait_for_function("()=>{const s=document.querySelector('#gpts-v3-host').shadowRoot;if(s.querySelector('#cyclePhase').textContent.includes('انتظار محاولة الشراء')&&!s.querySelector('#stop').disabled){s.querySelector('#stop').click();return true;}return false;}");page.wait_for_timeout(400)
    assert page.evaluate('__bidCalls')==calls and sh.locator('#buyCount').inner_text()=='0'
    print('PASS: Stop during the Deep pre-buy delay dispatches no bid and records no purchase')

    # Repeated real offers are retained once each; equal player names do not merge different auctions.
    sh.locator('#autoBuy').uncheck();sh.locator('#engineMode').select_option('enhancer')
    page.evaluate("__makeModeOffers('profile-repeat',2);window.__testPages=undefined;window.__testItems.push(__testItems[0]);window.__testDelay=150")
    sh.locator('#scanMarket').click();sh.locator('#scanMarket').click()
    page.wait_for_function("()=>!document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#resultsCount').disabled")
    assert sh.locator('.market-card').count()==2 and sh.locator('.trade-history[data-seen="true"]').count()==2
    assert sh.locator('.market-card[data-trade-id="profile-repeat-0"]').count()==1
    assert sh.locator('.market-card[data-trade-id="profile-repeat-1"]').count()==1
    print('PASS: rapid refreshes never append duplicate Trade IDs, distinct same-player auctions stay visible and repeated server offers are explicitly labelled')

    # Direct-service profiles retain the original native shared-budget guard and never rebid an over-budget item.
    for mode in ['pharaoh','enhancer']:
      snap=request('connect')['result']['snapshot'];plan=request('prepareSearch',{'criteriaKey':snap['criteriaKey'],'prices':{'minBid':0,'maxBid':0,'minBin':0,'maxBin':1000}})['result']
      session_id=request('beginSession',{'engineMode':mode,'route':'sdk','planId':plan['planId'],'criteriaKey':snap['criteriaKey'],'maxPrice':1000,'maxSpend':1500,'maxBuys':2,'autoBuy':True})['result']['sessionId']
      for number in [1,2]:
        page.evaluate("resetTrade("+json.dumps('profile-budget-'+mode+'-'+str(number))+");window.__testPages=undefined")
        result=request('search',{'engineMode':mode,'purpose':'snipe','route':'sdk','planId':plan['planId'],'maxBin':1000,'criteriaKey':snap['criteriaKey'],'limit':5})['result']
        before=page.evaluate('__bidCalls');reply=request('buy',{'sessionId':session_id,'searchId':result['searchId'],'tradeId':'profile-budget-'+mode+'-'+str(number),'instanceId':'123456','expectedPrice':900})
        if number==1:assert reply['result']['status']=='bought' and reply['result']['purchaseRoute']=='ea-service-bid' and reply['result']['spent']==900
        else:assert reply['code']=='LIMIT' and page.evaluate('__bidCalls')==before
      request('cancel')
    print('PASS: Pharaoh/Enhancer service-bid routes preserve original-item identity, confirmed receipt and the immutable shared budget')
    page.evaluate('UTItemActionController.prototype.bid=window.__originalActionBid;window.__testDelay=50')
    sh.locator('#engineMode').select_option('codex');sh.locator('#searchRoute').select_option('screen');sh.locator('#resultsCount').fill('20')

    # Missing the isolated helper entry must give a setup diagnostic, never a .get crash or a market request.
    missing_page=context.new_page();missing_errors=[];missing_page.on('pageerror',lambda e:missing_errors.append(str(e)))
    missing_page.goto(URL)
    for entry in manifest['content_scripts']:
      if entry.get('world')=='MAIN':
        for filename in entry['js']:missing_page.add_script_tag(content=(ROOT/filename).read_text())
    missing_cdp=context.new_cdp_session(missing_page)
    missing_frame=missing_cdp.send('Page.getFrameTree')['frameTree']['frame']['id']
    missing_world=missing_cdp.send('Page.createIsolatedWorld',{'frameId':missing_frame,'worldName':'codex-missing-helper-test'})['executionContextId']
    missing_cdp.send('Runtime.evaluate',{'contextId':missing_world,'expression':shim})
    for filename in scripts:
      if filename=='ui-helpers.js':continue
      loaded=missing_cdp.send('Runtime.evaluate',{'contextId':missing_world,'expression':(ROOT/filename).read_text()+'\n//# sourceURL=chrome-extension://codex-missing/'+filename})
      assert 'exceptionDetails' not in loaded,loaded
    missing_page.locator('#gpts-v3-nav').click()
    missing_sh=missing_page.locator('#gpts-v3-host')
    assert missing_sh.locator('#start').is_disabled() and missing_sh.locator('#scanMarket').is_disabled()
    assert 'UI_HELPERS_MISSING' in missing_sh.locator('#uiDependencyStatus').inner_text()
    missing_sh.locator('#scanMarket').dispatch_event('click')
    assert 'UI_HELPERS_MISSING' in missing_sh.locator('#logs').inner_text()
    assert missing_page.evaluate('__testSearches')==0 and not missing_errors
    missing_page.close()
    print('PASS: omitted helper entry yields a reload diagnostic and no query, with no undefined .get exception')

    # A successful transport with no isWon state is uncertain, not a completed purchase.
    page.evaluate("resetTrade('uncertain-buy');window.__bidScenario='pending'")
    sh.locator('#autoBuy').check();sh.locator('#start').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#logs').textContent.includes('not confirmed won')")
    assert sh.locator('#buyCount').inner_text()=='0' and sh.locator('#spent').inner_text()=='0'
    snap=request('connect')['result']['snapshot']
    assert request('beginSession',{'criteriaKey':snap['criteriaKey'],'maxPrice':1000,'maxSpend':1000,'maxBuys':1})['code']=='PURCHASE_UNCERTAIN'
    print('PASS: unconfirmed native purchase never increments counters and blocks automatic retries')

    page.evaluate('window.__testMarketAllowed=false')
    sh.locator('#connectEA').click()
    page.wait_for_function("document.querySelector('#gpts-v3-host').shadowRoot.querySelector('#nativeConnectStatus').textContent.includes('unavailable')")
    with page.expect_download() as dl: sh.locator('#exportConnection').click()
    assert json.loads(Path(dl.value.path()).read_text())['stage']=='MARKET_UNAVAILABLE'
    print('PASS: EA market eligibility remains enforced; failure report replaces old success')
    assert not errors,errors
    page.screenshot(path='/tmp/GPT_SNIPE_v3.4_NATIVE_FUNCTIONS.png')
    browser.close()
